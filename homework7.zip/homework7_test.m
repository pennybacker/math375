% test newton_coef function
x = [0,2,3];
y = [1,2,4];
pass = 0;
if exist('newton_coef','file')
    c = newton_coef(x,y);
    if norm(c(:)-[1;0.5;0.5],inf) < 2*eps, pass = 1; end
end
if pass
    fprintf('newton_coef function: passed\n');
else
    fprintf('newton_coef function: failed\n');
end

% test newton_eval function
c = [1,0.5,0.5];
x = [0,2,3];
xx = [1,2,3];
pass = 0;
if exist('newton_eval','file')
    yy = newton_eval(c,x,xx);
    if norm(yy(:)-[1;2;4],inf) < 2*eps, pass = 1; end
end
if pass
    fprintf('newton_eval function: passed\n');
else
    fprintf('newton_eval function: failed\n');
end